import { useEffect, useRef, useState } from 'react';
import './App.css';

/**
 * 0 --- 0
 * 15 --- 300 
 */

function App() {

  const [clickedBy, setClickedBy] = useState(null);
  const [barCircleCoordinates, setBarCircleCoordinates] = useState({
    min: {
      coordinates: 0,
      value: 0
    },
    max: {
      coordinates: 300,
      value: 15
    },
  })
  const rangeRef = useRef(null);



  useEffect(() => {
    const onMouseClickReleaseHandler = (e) => {
      setClickedBy(null);
    }

    window.addEventListener("mouseup", onMouseClickReleaseHandler);

    return () => {
      window.removeEventListener("mouseup", onMouseClickReleaseHandler);
    }
  }, []);

  useEffect(() => {
    if (rangeRef.current) {
      const { width } = rangeRef.current.getBoundingClientRect();
      setBarCircleCoordinates({
        min: {
          coordinates: 0,
          value: 0
        },
        max: {
          coordinates: 0 + width,
          value: 15
        }
      })
    }
  }, [])

  const onMouseClickHandler = (info, e) => {
    setClickedBy(info.purpuse);
  };


  const mouseMoveHandler = (e) => {



    /**
     * left -- 0 -- 0
     * right -- 15 -- 300
     */
    const { left } = rangeRef.current.getBoundingClientRect();
    const value = e.clientX - left;
    if (value >= 0 && value <= 300 && clickedBy !== null) {
      const rangeValue = Math.ceil((Math.floor(value) * 15) / 300);

      if (clickedBy === "min" ? barCircleCoordinates["max"].value - rangeValue > 0 : rangeValue - barCircleCoordinates["min"].value > 0) {
        setBarCircleCoordinates((prevState) => {
          return {
            ...prevState,
            [clickedBy === "min" ? "min" : "max"]: {
              ...prevState[clickedBy === "min" ? "min" : "max"]
            },
            [clickedBy]: {
              coordinates: value,
              value: rangeValue
            }
          }
        });
      }
    }
  }

  const onMouseLeaveHandler = () => {
    setClickedBy(null);
  }




  return (
    <main>
      <div>
        {barCircleCoordinates.min.value} - {barCircleCoordinates.max.value}
      </div>
      <div className='range' ref={rangeRef} onMouseMove={mouseMoveHandler} onMouseLeave={onMouseLeaveHandler}>
        <div style={{
          left: barCircleCoordinates.min.coordinates + "px"
        }} className='circle__bar circle__bar1' onMouseDown={onMouseClickHandler.bind(null, { purpuse: "min" })}></div>
        <div style={{
          left: barCircleCoordinates.max.coordinates + "px"
        }} className='circle__bar circle__bar2' onMouseDown={onMouseClickHandler.bind(null, { purpuse: "max" })}></div>
      </div>
    </main>
  );
}

export default App;
